package ment1;

import java.text.ParseException;
import java.text.SimpleDataFormat;
import java.util.Data;

public class program
{
	public static int toInt(String s)
	{
		return Integer.parseInt(s);
	}
	
	public static long tolong(String s)
	{
		return Long.parseLong(s);
	}
	public static double todouble(String s)
	{
		return Double.parseDouble(s);
	}
	public static boolean toboolean(String s)
	{
		return Boolean.parseBoolean(s);
	}
	
	
	

	public static void main(String[] args)
	{
		String s = "1";
		System.out.println("To primitive int : "+toInt(s));
		System.out.println("To primitive long : "+tolong(s));
		System.out.println("To primitive double : "+todouble(s));
		System.out.println("To primitive boolean : "+toboolean(s));
		
		
		

	}

}
